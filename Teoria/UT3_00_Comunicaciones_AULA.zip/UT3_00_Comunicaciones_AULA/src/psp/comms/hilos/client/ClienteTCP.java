package psp.comms.hilos.client;

import psp.comms.hilos.model.Ejemplo;

import javax.smartcardio.ATR;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClienteTCP {

    public static void main(String[] args) {
        InetAddress direccion;
        Socket servidor = null;
        int PUERTO = 5000;

        System.out.println("Soy el cliente e intento conectarme");
        ObjectOutputStream bufferSalidaDatos = null;
        ObjectInputStream bufferEntradaDatos = null;

        try {
            direccion = InetAddress.getLocalHost();
            servidor = new Socket(direccion, PUERTO);
            System.out.println("Conexión realizada con exito");

            bufferSalidaDatos = new ObjectOutputStream(servidor.getOutputStream());
            Ejemplo datosSalida = new Ejemplo("Objeto enviado por el cliente", 1);
            bufferSalidaDatos.writeObject(datosSalida);
            System.out.println("Enviando al servidor el objeto " + datosSalida.toString());

            Thread.sleep(10000);

            bufferEntradaDatos = new ObjectInputStream(servidor.getInputStream());
            Ejemplo datosEntrada = (Ejemplo) bufferEntradaDatos.readObject();
            datosEntrada.mostrar();
            System.out.println("Recibido del servidor el objeto " + datosEntrada.toString());
            //System.out.println(datos.readUTF());

        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                bufferEntradaDatos.close();
                bufferSalidaDatos.close();
                if (servidor != null) {
                    servidor.close();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

}
